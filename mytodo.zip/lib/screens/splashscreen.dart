import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:project_todo_list/screens/home.dart';
import '../applocale/applocale.dart';




class SplachScreen extends StatelessWidget {
  const SplachScreen({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(
        const SystemUiOverlayStyle(statusBarColor: Colors.transparent));
    return const MaterialApp(
      home: MyHomePage(),
      localizationsDelegates: [
        AppLocale.delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate
      ],
      supportedLocales: [
        Locale("en", "EN"),
        Locale("ar", "AR"),
      ],
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key});

  @override
  MyHomePageState createState() => MyHomePageState();
}

class MyHomePageState extends State<MyHomePage> {
  @override
  void initState() {
    super.initState();
    startSplashScreenTimer();
  }
  startSplashScreenTimer() async {
    var duration = const Duration(seconds: 5);
    return Timer(duration, navigationToNextPage);
  }
  void navigationToNextPage() async {
    Navigator.pushAndRemoveUntil(
      context, MaterialPageRoute(builder: (context) => const Home()),
          (Route<dynamic> route) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[300],
      body: Center(
        child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            //crossAxisAlignment: CrossAxisAlignment.stretch,
            children:[
              const SizedBox(
                height: 100,
              ),
              Image.asset(
                'assets/images/to-do-list.png',
                height: 200,
                width: 200,
              ),
              Text(
                "${getLang(context, "MyName")}",
                  style:const TextStyle(
                      color: Colors.black,
                      fontSize: 20
                  ),
              ),
              const SizedBox(
                height: 150,
              ),
              const CircularProgressIndicator(
                backgroundColor: Colors.black,
              ),
              Container(
                  padding: const EdgeInsets.only(top: 20, bottom: 50),
                  child: Text(
                    "${getLang(context, "Waiting!!!")}",
                    style: const TextStyle(
                        color: Colors.black,
                        fontSize: 25
                    ),
                  )
              )
            ]
        ),
      ),
    );
  }
}